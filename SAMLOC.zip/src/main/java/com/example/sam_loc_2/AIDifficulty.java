package com.example.sam_loc_2;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public enum AIDifficulty {
    EASY, MEDIUM, HARD
}

